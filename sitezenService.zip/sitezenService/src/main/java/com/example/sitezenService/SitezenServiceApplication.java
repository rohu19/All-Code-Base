package com.example.sitezenService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SitezenServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SitezenServiceApplication.class, args);
	}

}
