package com.example.classtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClassTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClassTestApplication.class, args);
	}

}
