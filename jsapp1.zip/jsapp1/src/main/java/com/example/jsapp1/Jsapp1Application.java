package com.example.jsapp1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jsapp1Application {

	public static void main(String[] args) {
		SpringApplication.run(Jsapp1Application.class, args);
	}

}
