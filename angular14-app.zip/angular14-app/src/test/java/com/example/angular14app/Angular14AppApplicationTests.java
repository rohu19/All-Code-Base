package com.example.angular14app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Angular14AppApplicationTests {

	@Test
	void contextLoads() {
	}

}
