package com.example.angular14app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Angular14AppApplication {

	public static void main(String[] args) {
		SpringApplication.run(Angular14AppApplication.class, args);
	}

}
