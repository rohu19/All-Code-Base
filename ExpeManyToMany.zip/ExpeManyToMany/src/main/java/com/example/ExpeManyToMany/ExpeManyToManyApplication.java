package com.example.ExpeManyToMany;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExpeManyToManyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExpeManyToManyApplication.class, args);
	}

}
