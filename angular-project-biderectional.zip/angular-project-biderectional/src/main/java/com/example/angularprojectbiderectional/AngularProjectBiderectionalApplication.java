package com.example.angularprojectbiderectional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AngularProjectBiderectionalApplication {

	public static void main(String[] args) {
		SpringApplication.run(AngularProjectBiderectionalApplication.class, args);
	}

}
